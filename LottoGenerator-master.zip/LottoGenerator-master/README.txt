﻿A részletes magyarázása ennek a projectnek a http://sanfranciscoboljottem.com oldalon található, a Java kurzus alatt. 
A tanfolyam ingyenesen elérhető bárki számára, csupán be kell regisztrálni.